
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Search } from "lucide-react";

// Sample company data
const companies = [
  {
    id: 1,
    name: "Tech Solutions Inc",
    industry: "Information Technology",
    location: "San Francisco, CA",
    openPositions: 12,
    logo: "/placeholder.svg",
    description: "Tech Solutions Inc is a leading provider of innovative software solutions for businesses worldwide. With a focus on cutting-edge technologies, we help organizations transform their digital presence.",
    positions: [
      { title: "Senior Frontend Developer", experience: "5+ years", type: "Full-time" },
      { title: "Backend Engineer", experience: "3+ years", type: "Full-time" },
      { title: "DevOps Specialist", experience: "4+ years", type: "Full-time" }
    ]
  },
  {
    id: 2,
    name: "Innovate Systems",
    industry: "Software Development",
    location: "New York, NY",
    openPositions: 8,
    logo: "/placeholder.svg",
    description: "Innovate Systems builds enterprise-grade applications that help businesses streamline their operations and improve productivity across all departments.",
    positions: [
      { title: "React Developer", experience: "2+ years", type: "Full-time" },
      { title: "Product Manager", experience: "5+ years", type: "Full-time" },
      { title: "UX Researcher", experience: "3+ years", type: "Contract" }
    ]
  },
  {
    id: 3,
    name: "Global Tech",
    industry: "Technology Consulting",
    location: "Austin, TX",
    openPositions: 15,
    logo: "/placeholder.svg",
    description: "Global Tech partners with businesses to provide strategic technology consulting and implementation services, helping them navigate digital transformation.",
    positions: [
      { title: "Full Stack Engineer", experience: "4+ years", type: "Full-time" },
      { title: "Cloud Architect", experience: "6+ years", type: "Full-time" },
      { title: "Data Scientist", experience: "3+ years", type: "Full-time" }
    ]
  },
  {
    id: 4,
    name: "Webflow Enterprises",
    industry: "Web Development",
    location: "Seattle, WA",
    openPositions: 6,
    logo: "/placeholder.svg",
    description: "Webflow Enterprises specializes in creating stunning, high-performance websites and web applications for clients across various industries.",
    positions: [
      { title: "UI/UX Designer", experience: "3+ years", type: "Full-time" },
      { title: "Frontend Developer", experience: "2+ years", type: "Contract" },
      { title: "Project Manager", experience: "4+ years", type: "Full-time" }
    ]
  },
  {
    id: 5,
    name: "Smart Solutions",
    industry: "AI & Machine Learning",
    location: "Boston, MA",
    openPositions: 10,
    logo: "/placeholder.svg",
    description: "Smart Solutions leverages artificial intelligence and machine learning to develop intelligent applications that solve complex business problems.",
    positions: [
      { title: "Machine Learning Engineer", experience: "4+ years", type: "Full-time" },
      { title: "Product Manager", experience: "5+ years", type: "Full-time" },
      { title: "Python Developer", experience: "3+ years", type: "Full-time" }
    ]
  }
];

export function CompanyList() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCompany, setSelectedCompany] = useState<any>(null);

  const filteredCompanies = companies.filter(company => 
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    company.industry.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Browse Companies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative mb-6">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input 
              placeholder="Search companies by name, industry, or location..." 
              className="pl-8" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCompanies.map((company) => (
              <Card key={company.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardContent className="p-0">
                  <div className="p-4">
                    <div className="flex items-center mb-3">
                      <img 
                        src={company.logo} 
                        alt={company.name} 
                        className="h-12 w-12 mr-3 rounded-full"
                      />
                      <div>
                        <h3 className="font-semibold">{company.name}</h3>
                        <p className="text-sm text-gray-500">{company.location}</p>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm text-gray-700 line-clamp-2">{company.description}</p>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        {company.industry}
                      </Badge>
                      <span className="text-sm font-medium text-green-600">
                        {company.openPositions} open positions
                      </span>
                    </div>
                  </div>
                  
                  <div className="border-t p-3 bg-gray-50">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="w-full"
                      onClick={() => setSelectedCompany(company)}
                    >
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {filteredCompanies.length === 0 && (
            <div className="text-center py-10">
              <p className="text-gray-500">No companies found matching your search criteria.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Company Details Dialog */}
      <Dialog open={!!selectedCompany} onOpenChange={(open) => !open && setSelectedCompany(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Company Details</DialogTitle>
            <DialogDescription>
              Information about the company and open positions
            </DialogDescription>
          </DialogHeader>
          
          {selectedCompany && (
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <img
                  src={selectedCompany.logo}
                  alt={selectedCompany.name}
                  className="h-16 w-16 rounded-full"
                />
                <div>
                  <h3 className="text-xl font-semibold">{selectedCompany.name}</h3>
                  <p className="text-gray-500">{selectedCompany.location}</p>
                  <div className="mt-2">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      {selectedCompany.industry}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="text-lg font-medium mb-2">About the Company</h4>
                <p className="text-gray-700">{selectedCompany.description}</p>
              </div>
              
              <div>
                <h4 className="text-lg font-medium mb-3">Open Positions ({selectedCompany.openPositions})</h4>
                <div className="space-y-3">
                  {selectedCompany.positions.map((position: any, index: number) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h5 className="font-semibold">{position.title}</h5>
                            <div className="flex space-x-3 mt-1">
                              <span className="text-sm text-gray-600">Experience: {position.experience}</span>
                              <span className="text-sm text-gray-600">Type: {position.type}</span>
                            </div>
                          </div>
                          <Button size="sm">Apply Now</Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
