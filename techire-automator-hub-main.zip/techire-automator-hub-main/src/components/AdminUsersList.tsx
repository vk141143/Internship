import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, CheckCircle, Clock, XCircle } from "lucide-react";

// Sample user data
const users = [
  {
    id: 1,
    name: "John Doe",
    email: "john.doe@example.com",
    position: "Software Developer",
    experience: "5 years",
    applications: 15,
    selected: 6,
    rejected: 7,
    pending: 2,
    lastActive: "2023-04-10",
    profileProgress: 85,
    avatar: "/placeholder.svg"
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane.smith@example.com",
    position: "UI/UX Designer",
    experience: "3 years",
    applications: 10,
    selected: 4,
    rejected: 5,
    pending: 1,
    lastActive: "2023-04-08",
    profileProgress: 70,
    avatar: "/placeholder.svg"
  },
  {
    id: 3,
    name: "Michael Johnson",
    email: "michael.johnson@example.com",
    position: "Product Manager",
    experience: "7 years",
    applications: 8,
    selected: 2,
    rejected: 3,
    pending: 3,
    lastActive: "2023-04-12",
    profileProgress: 95,
    avatar: "/placeholder.svg"
  },
  {
    id: 4,
    name: "Sarah Williams",
    email: "sarah.williams@example.com",
    position: "Data Scientist",
    experience: "4 years",
    applications: 12,
    selected: 5,
    rejected: 6,
    pending: 1,
    lastActive: "2023-04-05",
    profileProgress: 60,
    avatar: "/placeholder.svg"
  },
  {
    id: 5,
    name: "Robert Brown",
    email: "robert.brown@example.com",
    position: "DevOps Engineer",
    experience: "6 years",
    applications: 9,
    selected: 3,
    rejected: 4,
    pending: 2,
    lastActive: "2023-04-11",
    profileProgress: 80,
    avatar: "/placeholder.svg"
  }
];

// Sample user applications
const userApplications = [
  {
    id: 1,
    company: "Tech Solutions Inc",
    position: "Senior Frontend Developer",
    date: "2023-04-02",
    status: "selected",
    nextRound: "Technical Interview",
    logo: "/placeholder.svg"
  },
  {
    id: 2,
    company: "Innovate Systems",
    position: "React Developer",
    date: "2023-03-25",
    status: "rejected",
    logo: "/placeholder.svg"
  },
  {
    id: 3,
    company: "Global Tech",
    position: "Software Engineer",
    date: "2023-03-30",
    status: "selected",
    nextRound: "HR Discussion",
    logo: "/placeholder.svg"
  },
  {
    id: 4,
    company: "Webflow Enterprises",
    position: "Frontend Developer",
    date: "2023-03-15",
    status: "rejected",
    logo: "/placeholder.svg"
  },
  {
    id: 5,
    company: "Smart Solutions",
    position: "JavaScript Developer",
    date: "2023-04-05",
    status: "pending",
    logo: "/placeholder.svg"
  },
  {
    id: 6,
    company: "DevOps Labs",
    position: "Full Stack Developer",
    date: "2023-03-20",
    status: "selected",
    nextRound: "Final Interview",
    logo: "/placeholder.svg"
  }
];

interface AdminUsersListProps {
  searchQuery?: string;
}

export function AdminUsersList({ searchQuery = "" }: AdminUsersListProps) {
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [filteredUsers, setFilteredUsers] = useState(users);

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredUsers(users);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = users.filter(
        user => 
          user.name.toLowerCase().includes(query) || 
          user.email.toLowerCase().includes(query) || 
          user.position.toLowerCase().includes(query)
      );
      setFilteredUsers(filtered);
    }
  }, [searchQuery]);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'selected':
        return <Badge className="bg-green-500">Selected</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'pending':
        return <Badge variant="outline" className="text-amber-500 border-amber-500">In Progress</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <>
      <Card className="hover:shadow-md transition-shadow duration-300">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Total Applications</TableHead>
                <TableHead>Success Rate</TableHead>
                <TableHead>Profile Completion</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <TableRow key={user.id} className="hover:bg-muted/50 transition-colors cursor-pointer" onClick={() => setSelectedUser(user)}>
                    <TableCell>
                      <div className="flex items-center">
                        <Avatar className="h-9 w-9 mr-3 hover:scale-110 transition-transform">
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <p>{user.position}</p>
                      <p className="text-sm text-gray-500">{user.experience}</p>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-1">
                        <span className="font-medium">{user.applications}</span>
                        <span className="text-sm text-gray-500">applications</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">
                          {Math.round((user.selected / user.applications) * 100)}%
                        </span>
                        <div className="flex space-x-1 text-sm">
                          <span className="text-green-500">{user.selected}</span>
                          <span className="text-gray-400">/</span>
                          <span className="text-red-500">{user.rejected}</span>
                          <span className="text-gray-400">/</span>
                          <span className="text-amber-500">{user.pending}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full">
                        <div className="flex justify-between mb-1">
                          <span className="text-xs font-medium">{user.profileProgress}%</span>
                        </div>
                        <Progress value={user.profileProgress} className="h-2" />
                      </div>
                    </TableCell>
                    <TableCell>{new Date(user.lastActive).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedUser(user);
                        }}
                        className="hover:bg-primary hover:text-primary-foreground transition-colors"
                      >
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No users found matching "{searchQuery}"
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* User Details Dialog */}
      <Dialog open={!!selectedUser} onOpenChange={(open) => !open && setSelectedUser(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription>
              Detailed information about the user's profile and applications
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div>
              <div className="flex items-center mb-6">
                <Avatar className="h-16 w-16 mr-4 hover:scale-105 transition-transform">
                  <AvatarImage src={selectedUser.avatar} alt={selectedUser.name} />
                  <AvatarFallback>{selectedUser.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-xl font-semibold">{selectedUser.name}</h3>
                  <p className="text-gray-500">{selectedUser.email}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{selectedUser.position}</Badge>
                    <Badge variant="outline">{selectedUser.experience}</Badge>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card className="hover:shadow-md transition-shadow duration-300">
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-3">Profile Completion</h4>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Overall Profile</span>
                          <span className="text-sm font-medium">{selectedUser.profileProgress}%</span>
                        </div>
                        <Progress value={selectedUser.profileProgress} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Resume Quality</span>
                          <span className="text-sm font-medium">78%</span>
                        </div>
                        <Progress value={78} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Skills Relevance</span>
                          <span className="text-sm font-medium">92%</span>
                        </div>
                        <Progress value={92} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="hover:shadow-md transition-shadow duration-300">
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-3">Application Statistics</h4>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="bg-gray-50 dark:bg-gray-800 p-2 rounded-md text-center hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                        <p className="text-3xl font-bold">{selectedUser.applications}</p>
                        <p className="text-xs text-gray-500">Total Applications</p>
                      </div>
                      <div className="bg-green-50 dark:bg-green-900/20 p-2 rounded-md text-center hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors">
                        <p className="text-3xl font-bold text-green-600 dark:text-green-400">{selectedUser.selected}</p>
                        <p className="text-xs text-gray-500">Selected</p>
                      </div>
                      <div className="bg-red-50 dark:bg-red-900/20 p-2 rounded-md text-center hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors">
                        <p className="text-3xl font-bold text-red-600 dark:text-red-400">{selectedUser.rejected}</p>
                        <p className="text-xs text-gray-500">Rejected</p>
                      </div>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium mb-2">Success Rate by Industry</h5>
                      <div className="space-y-2">
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-xs">Software Development</span>
                            <span className="text-xs font-medium">67%</span>
                          </div>
                          <Progress value={67} className="h-1.5" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-xs">Web Design</span>
                            <span className="text-xs font-medium">42%</span>
                          </div>
                          <Progress value={42} className="h-1.5" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-xs">Product Management</span>
                            <span className="text-xs font-medium">25%</span>
                          </div>
                          <Progress value={25} className="h-1.5" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Tabs defaultValue="applications">
                <TabsList className="mb-4">
                  <TabsTrigger value="applications">Recent Applications</TabsTrigger>
                  <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
                </TabsList>
                
                <TabsContent value="applications">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Company</TableHead>
                        <TableHead>Position</TableHead>
                        <TableHead>Applied Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Next Round</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {userApplications.map((app) => (
                        <TableRow key={app.id} className="hover:bg-muted/50 transition-colors">
                          <TableCell>
                            <div className="flex items-center">
                              <img 
                                src={app.logo} 
                                alt={app.company} 
                                className="h-8 w-8 mr-2 rounded-full"
                              />
                              {app.company}
                            </div>
                          </TableCell>
                          <TableCell>{app.position}</TableCell>
                          <TableCell>{new Date(app.date).toLocaleDateString()}</TableCell>
                          <TableCell>{getStatusBadge(app.status)}</TableCell>
                          <TableCell>
                            {app.nextRound ? app.nextRound : "-"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TabsContent>
                
                <TabsContent value="analytics">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="hover:shadow-md transition-shadow duration-300">
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-3">Application Outcome Over Time</h4>
                        <div className="flex items-center justify-center h-48 bg-gray-50 dark:bg-gray-800 rounded-md animate-pulse">
                          <BarChart className="h-10 w-10 text-gray-400" />
                          <span className="ml-2 text-gray-500">Analytics Chart Placeholder</span>
                        </div>
                        <div className="flex justify-center mt-3 space-x-4 text-sm">
                          <div className="flex items-center">
                            <div className="h-3 w-3 rounded-full bg-green-500 mr-1"></div>
                            <span>Selected</span>
                          </div>
                          <div className="flex items-center">
                            <div className="h-3 w-3 rounded-full bg-red-500 mr-1"></div>
                            <span>Rejected</span>
                          </div>
                          <div className="flex items-center">
                            <div className="h-3 w-3 rounded-full bg-amber-500 mr-1"></div>
                            <span>Pending</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="hover:shadow-md transition-shadow duration-300">
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-3">Interview Performance</h4>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Technical Skills</span>
                              <span className="text-sm font-medium">85%</span>
                            </div>
                            <Progress value={85} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Communication</span>
                              <span className="text-sm font-medium">75%</span>
                            </div>
                            <Progress value={75} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Problem Solving</span>
                              <span className="text-sm font-medium">90%</span>
                            </div>
                            <Progress value={90} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Cultural Fit</span>
                              <span className="text-sm font-medium">80%</span>
                            </div>
                            <Progress value={80} className="h-2" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
