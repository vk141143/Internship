
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { Upload } from "lucide-react";

export function ResumeUploader() {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      
      // Only accept PDF and Word documents
      if (selectedFile.type === "application/pdf" || 
          selectedFile.type === "application/msword" ||
          selectedFile.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
        setFile(selectedFile);
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please upload a PDF or Word document.",
          variant: "destructive",
        });
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      
      // Only accept PDF and Word documents
      if (droppedFile.type === "application/pdf" || 
          droppedFile.type === "application/msword" ||
          droppedFile.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
        setFile(droppedFile);
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please upload a PDF or Word document.",
          variant: "destructive",
        });
      }
    }
  };

  const handleUpload = () => {
    if (!file) {
      toast({
        title: "No File Selected",
        description: "Please select a file to upload.",
        variant: "destructive",
      });
      return;
    }

    // In a real app, you would upload the file to a backend
    toast({
      title: "Resume Uploaded",
      description: `Your resume "${file.name}" has been uploaded successfully.`,
    });
  };

  return (
    <div className="space-y-4">
      <div 
        className={`border-2 border-dashed rounded-lg p-6 text-center ${
          isDragging ? "border-primary bg-primary/5" : "border-gray-300"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <Upload className="h-10 w-10 mx-auto mb-2 text-gray-400" />
        <p className="text-sm font-medium mb-1">
          Drag and drop your resume here
        </p>
        <p className="text-xs text-gray-500 mb-4">
          Supported formats: PDF, DOC, DOCX
        </p>
        
        <Input
          type="file"
          id="resume-upload"
          className="hidden"
          accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          onChange={handleFileChange}
        />
        <Button 
          variant="outline" 
          onClick={() => document.getElementById("resume-upload")?.click()}
          size="sm"
        >
          Browse Files
        </Button>
      </div>
      
      {file && (
        <div className="bg-gray-50 p-3 rounded-md flex justify-between items-center">
          <div>
            <p className="font-medium">{file.name}</p>
            <p className="text-xs text-gray-500">
              {(file.size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
          <Button 
            size="sm"
            onClick={() => setFile(null)}
            variant="ghost"
          >
            Remove
          </Button>
        </div>
      )}
      
      <Button 
        className="w-full"
        disabled={!file}
        onClick={handleUpload}
      >
        Upload Resume
      </Button>
    </div>
  );
}
