
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar, CheckCircle, Clock, XCircle } from "lucide-react";

// Sample application data
const applications = [
  {
    id: 1,
    company: "Tech Solutions Inc",
    position: "Senior Frontend Developer",
    date: "2023-04-10",
    status: "selected",
    nextRound: "2023-04-18 14:00",
    nextRoundType: "Technical Interview",
    logo: "/placeholder.svg"
  },
  {
    id: 2,
    company: "Innovate Systems",
    position: "React Developer",
    date: "2023-04-05",
    status: "rejected",
    logo: "/placeholder.svg"
  },
  {
    id: 3,
    company: "Global Tech",
    position: "Full Stack Engineer",
    date: "2023-04-01",
    status: "selected",
    nextRound: "2023-04-15 10:30",
    nextRoundType: "HR Discussion",
    logo: "/placeholder.svg"
  },
  {
    id: 4,
    company: "Webflow Enterprises",
    position: "UI/UX Designer",
    date: "2023-03-28",
    status: "pending",
    logo: "/placeholder.svg"
  },
  {
    id: 5,
    company: "Smart Solutions",
    position: "Product Manager",
    date: "2023-03-25",
    status: "rejected",
    logo: "/placeholder.svg"
  },
  {
    id: 6,
    company: "DevOps Labs",
    position: "DevOps Engineer",
    date: "2023-03-20",
    status: "pending",
    logo: "/placeholder.svg"
  }
];

// Sample company details
const companyDetails = {
  name: "Tech Solutions Inc",
  description: "Tech Solutions Inc is a leading provider of innovative software solutions for businesses worldwide. With a focus on cutting-edge technologies, we help organizations transform their digital presence.",
  industry: "Information Technology",
  location: "San Francisco, CA",
  employees: "1000-5000",
  website: "https://techsolutions-example.com",
  founded: "2005",
  jd: "As a Senior Frontend Developer, you will be responsible for building high-performance web applications using React, TypeScript, and modern frontend tools. You'll work closely with UX designers and backend developers to deliver exceptional user experiences.",
  requirements: [
    "5+ years of professional frontend development experience",
    "Strong proficiency in React, TypeScript, and state management libraries",
    "Experience with responsive design and cross-browser compatibility",
    "Understanding of web performance optimization techniques",
    "Familiarity with Agile development methodologies"
  ]
};

export function ApplicationsList() {
  const [selectedApplication, setSelectedApplication] = useState<any>(null);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'selected':
        return <Badge className="bg-green-500">Selected</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'pending':
        return <Badge variant="outline" className="text-amber-500 border-amber-500">In Progress</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Your Job Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Company</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Applied Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Next Round</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {applications.map((app) => (
                <TableRow key={app.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <img 
                        src={app.logo} 
                        alt={app.company} 
                        className="h-8 w-8 mr-2 rounded-full"
                      />
                      {app.company}
                    </div>
                  </TableCell>
                  <TableCell>{app.position}</TableCell>
                  <TableCell>{new Date(app.date).toLocaleDateString()}</TableCell>
                  <TableCell>{getStatusBadge(app.status)}</TableCell>
                  <TableCell>
                    {app.nextRound ? (
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-blue-500" />
                        {new Date(app.nextRound).toLocaleString()}
                      </div>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setSelectedApplication(app)}
                    >
                      Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Application Details Dialog */}
      <Dialog open={!!selectedApplication} onOpenChange={(open) => !open && setSelectedApplication(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
            <DialogDescription>
              Information about your job application
            </DialogDescription>
          </DialogHeader>
          
          {selectedApplication && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1 space-y-4">
                <div className="flex items-center space-x-4">
                  <img
                    src={selectedApplication.logo}
                    alt={selectedApplication.company}
                    className="h-16 w-16 rounded-full"
                  />
                  <div>
                    <h3 className="font-semibold">{selectedApplication.company}</h3>
                    <p className="text-sm text-gray-500">{companyDetails.location}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="font-medium">Industry:</span> {companyDetails.industry}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Employees:</span> {companyDetails.employees}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Founded:</span> {companyDetails.founded}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Website:</span>{" "}
                    <a href={companyDetails.website} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                      {companyDetails.website}
                    </a>
                  </div>
                </div>
                
                <div className="pt-2">
                  <h4 className="font-medium text-sm">Application Status</h4>
                  <div className="mt-2 flex items-center">
                    {selectedApplication.status === 'selected' ? (
                      <>
                        <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                        <span>Selected for next round</span>
                      </>
                    ) : selectedApplication.status === 'rejected' ? (
                      <>
                        <XCircle className="h-5 w-5 text-red-500 mr-2" />
                        <span>Application rejected</span>
                      </>
                    ) : (
                      <>
                        <Clock className="h-5 w-5 text-amber-500 mr-2" />
                        <span>Application in progress</span>
                      </>
                    )}
                  </div>
                  
                  {selectedApplication.nextRound && (
                    <div className="mt-4">
                      <h4 className="font-medium text-sm">Next Round</h4>
                      <div className="mt-1 p-2 bg-blue-50 rounded-md">
                        <p className="font-medium">{selectedApplication.nextRoundType}</p>
                        <p className="text-sm flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-blue-500" />
                          {new Date(selectedApplication.nextRound).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="md:col-span-2">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold">{selectedApplication.position}</h3>
                    <p className="text-sm text-gray-500">Applied on {new Date(selectedApplication.date).toLocaleDateString()}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium">Company Description</h4>
                    <p className="text-sm mt-1">{companyDetails.description}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium">Job Description</h4>
                    <p className="text-sm mt-1">{companyDetails.jd}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium">Requirements</h4>
                    <ul className="list-disc pl-5 mt-1 text-sm space-y-1">
                      {companyDetails.requirements.map((req, index) => (
                        <li key={index}>{req}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
