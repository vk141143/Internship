import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { UploadCloud, Save } from "lucide-react";

interface ProfileFormProps {
  onSave: (data: any, progress: number) => void;
  initialData?: any;
}

export function ProfileForm({ onSave, initialData }: ProfileFormProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState(initialData || {
    name: "John Doe",
    title: "Software Developer",
    experience: "5",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    skills: "JavaScript, React, TypeScript, Node.js, HTML, CSS",
    about: "Experienced software developer with a passion for creating intuitive and performant web applications.",
    avatar: "/placeholder.svg"
  });
  
  const [profileImage, setProfileImage] = useState<string | null>(formData.avatar);
  const [isEditing, setIsEditing] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string, name: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setProfileImage(event.target?.result as string);
        setFormData(prev => ({ ...prev, avatar: event.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const calculateProfileProgress = () => {
    const fields = [
      formData.name,
      formData.title,
      formData.experience,
      formData.email,
      formData.phone,
      formData.location,
      formData.skills,
      formData.about,
      formData.avatar !== "/placeholder.svg" ? formData.avatar : null
    ];
    
    const filledFields = fields.filter(field => field).length;
    return Math.round((filledFields / fields.length) * 100);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const progress = calculateProfileProgress();
    
    toast({
      title: "Profile Updated",
      description: "Your profile information has been saved successfully.",
    });
    
    onSave(formData, progress);
    setIsEditing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex justify-center mb-4">
        <div className="space-y-2 text-center">
          <Avatar className="h-24 w-24 mx-auto border-2 border-primary">
            <AvatarImage src={profileImage || "/placeholder.svg"} alt="Profile" />
            <AvatarFallback>{formData.name?.charAt(0) || "U"}</AvatarFallback>
          </Avatar>
          
          <div className="flex flex-col items-center">
            <Label 
              htmlFor="avatar-upload" 
              className="cursor-pointer text-sm text-primary hover:text-primary/80 transition-colors flex items-center gap-1"
            >
              <UploadCloud className="h-4 w-4" />
              Upload Photo
            </Label>
            <Input 
              id="avatar-upload" 
              type="file" 
              accept="image/*" 
              className="hidden" 
              onChange={handleImageUpload} 
            />
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label htmlFor="name" className="text-sm font-medium">
            Full Name
          </label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            readOnly={!isEditing}
            required
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="title" className="text-sm font-medium">
            Job Title
          </label>
          <Input
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            readOnly={!isEditing}
            required
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="experience" className="text-sm font-medium">
            Years of Experience
          </label>
          <Select 
            defaultValue={formData.experience}
            onValueChange={(value) => handleSelectChange(value, "experience")}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select experience" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 year</SelectItem>
              <SelectItem value="2">2 years</SelectItem>
              <SelectItem value="3">3 years</SelectItem>
              <SelectItem value="4">4 years</SelectItem>
              <SelectItem value="5">5 years</SelectItem>
              <SelectItem value="6">6 years</SelectItem>
              <SelectItem value="7">7 years</SelectItem>
              <SelectItem value="8">8 years</SelectItem>
              <SelectItem value="9">9 years</SelectItem>
              <SelectItem value="10+">10+ years</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium">
            Email
          </label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            readOnly={!isEditing}
            required
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="phone" className="text-sm font-medium">
            Phone Number
          </label>
          <Input
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            readOnly={!isEditing}
          />
        </div>
        
        <div className="space-y-2">
          <label htmlFor="location" className="text-sm font-medium">
            Location
          </label>
          <Input
            id="location"
            name="location"
            value={formData.location}
            onChange={handleChange}
            readOnly={!isEditing}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <label htmlFor="skills" className="text-sm font-medium">
          Skills (comma separated)
        </label>
        <Textarea
          id="skills"
          name="skills"
          value={formData.skills}
          onChange={handleChange}
          rows={2}
        />
      </div>
      
      <div className="space-y-2">
        <label htmlFor="about" className="text-sm font-medium">
          About
        </label>
        <Textarea
          id="about"
          name="about"
          value={formData.about}
          onChange={handleChange}
          rows={4}
        />
      </div>
      
      <div className="flex justify-end space-x-2 pt-2">
        {!isEditing ? (
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-2"
          >
            <Save className="h-4 w-4" /> Edit Profile
          </Button>
        ) : (
          <>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => {
                setFormData(initialData);
                setIsEditing(false);
              }}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex items-center gap-2"
            >
              <Save className="h-4 w-4" /> Save Changes
            </Button>
          </>
        )}
      </div>
    </form>
  );
}
