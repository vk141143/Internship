
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Plus, Save, Trash } from "lucide-react";

export function ResumeBuilder() {
  const { toast } = useToast();
  
  const [personalInfo, setPersonalInfo] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
  });

  const [education, setEducation] = useState([
    { degree: "", school: "", year: "", description: "" }
  ]);

  const [experience, setExperience] = useState([
    { title: "", company: "", duration: "", description: "" }
  ]);

  const [skills, setSkills] = useState([""]);

  const handlePersonalInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPersonalInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleEducationChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const newEducation = [...education];
    newEducation[index] = { ...newEducation[index], [name]: value };
    setEducation(newEducation);
  };

  const handleExperienceChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const newExperience = [...experience];
    newExperience[index] = { ...newExperience[index], [name]: value };
    setExperience(newExperience);
  };

  const handleSkillChange = (index: number, value: string) => {
    const newSkills = [...skills];
    newSkills[index] = value;
    setSkills(newSkills);
  };

  const addEducation = () => {
    setEducation([...education, { degree: "", school: "", year: "", description: "" }]);
  };

  const removeEducation = (index: number) => {
    if (education.length > 1) {
      setEducation(education.filter((_, i) => i !== index));
    }
  };

  const addExperience = () => {
    setExperience([...experience, { title: "", company: "", duration: "", description: "" }]);
  };

  const removeExperience = (index: number) => {
    if (experience.length > 1) {
      setExperience(experience.filter((_, i) => i !== index));
    }
  };

  const addSkill = () => {
    setSkills([...skills, ""]);
  };

  const removeSkill = (index: number) => {
    if (skills.length > 1) {
      setSkills(skills.filter((_, i) => i !== index));
    }
  };

  const handleGenerateResume = () => {
    // In a real app, you would generate a PDF or send data to a backend
    toast({
      title: "Resume Generated",
      description: "Your resume has been created successfully.",
    });
  };

  return (
    <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-1">
      {/* Personal Information */}
      <div>
        <h3 className="text-sm font-semibold mb-3">Personal Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Input
            placeholder="Full Name"
            name="name"
            value={personalInfo.name}
            onChange={handlePersonalInfoChange}
          />
          <Input
            placeholder="Email"
            name="email"
            type="email"
            value={personalInfo.email}
            onChange={handlePersonalInfoChange}
          />
          <Input
            placeholder="Phone"
            name="phone"
            value={personalInfo.phone}
            onChange={handlePersonalInfoChange}
          />
          <Input
            placeholder="Location"
            name="location"
            value={personalInfo.location}
            onChange={handlePersonalInfoChange}
          />
        </div>
        <Textarea
          placeholder="Professional Summary"
          name="summary"
          className="mt-3"
          value={personalInfo.summary}
          onChange={handlePersonalInfoChange}
        />
      </div>

      {/* Education */}
      <div>
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-semibold">Education</h3>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={addEducation}
            className="h-7 px-2"
          >
            <Plus className="h-4 w-4 mr-1" /> Add
          </Button>
        </div>
        
        {education.map((edu, index) => (
          <div key={index} className="p-3 border rounded-md mb-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <Input
                placeholder="Degree/Certification"
                name="degree"
                value={edu.degree}
                onChange={(e) => handleEducationChange(index, e)}
              />
              <Input
                placeholder="School/Institution"
                name="school"
                value={edu.school}
                onChange={(e) => handleEducationChange(index, e)}
              />
              <Input
                placeholder="Year of Completion"
                name="year"
                value={edu.year}
                onChange={(e) => handleEducationChange(index, e)}
              />
            </div>
            <Textarea
              placeholder="Description"
              name="description"
              value={edu.description}
              onChange={(e) => handleEducationChange(index, e)}
              className="mb-2"
            />
            {education.length > 1 && (
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={() => removeEducation(index)}
                className="h-7 px-2 text-red-500 hover:text-red-700"
              >
                <Trash className="h-4 w-4 mr-1" /> Remove
              </Button>
            )}
          </div>
        ))}
      </div>

      {/* Work Experience */}
      <div>
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-semibold">Work Experience</h3>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={addExperience}
            className="h-7 px-2"
          >
            <Plus className="h-4 w-4 mr-1" /> Add
          </Button>
        </div>
        
        {experience.map((exp, index) => (
          <div key={index} className="p-3 border rounded-md mb-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <Input
                placeholder="Job Title"
                name="title"
                value={exp.title}
                onChange={(e) => handleExperienceChange(index, e)}
              />
              <Input
                placeholder="Company"
                name="company"
                value={exp.company}
                onChange={(e) => handleExperienceChange(index, e)}
              />
              <Input
                placeholder="Duration (e.g., 2018-2021)"
                name="duration"
                value={exp.duration}
                onChange={(e) => handleExperienceChange(index, e)}
              />
            </div>
            <Textarea
              placeholder="Job Description and Achievements"
              name="description"
              value={exp.description}
              onChange={(e) => handleExperienceChange(index, e)}
              className="mb-2"
            />
            {experience.length > 1 && (
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={() => removeExperience(index)}
                className="h-7 px-2 text-red-500 hover:text-red-700"
              >
                <Trash className="h-4 w-4 mr-1" /> Remove
              </Button>
            )}
          </div>
        ))}
      </div>

      {/* Skills */}
      <div>
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-semibold">Skills</h3>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={addSkill}
            className="h-7 px-2"
          >
            <Plus className="h-4 w-4 mr-1" /> Add
          </Button>
        </div>
        
        <div className="space-y-2">
          {skills.map((skill, index) => (
            <div key={index} className="flex gap-2">
              <Input
                placeholder="Skill (e.g., JavaScript, Project Management)"
                value={skill}
                onChange={(e) => handleSkillChange(index, e.target.value)}
              />
              {skills.length > 1 && (
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => removeSkill(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      <Button 
        className="w-full mt-6"
        onClick={handleGenerateResume}
      >
        <Save className="h-4 w-4 mr-2" /> Generate Resume
      </Button>
    </div>
  );
}
