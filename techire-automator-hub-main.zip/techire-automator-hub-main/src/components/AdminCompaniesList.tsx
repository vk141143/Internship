import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, CheckCircle, Clock, XCircle } from "lucide-react";

// Sample company data
const companies = [
  {
    id: 1,
    name: "Tech Solutions Inc",
    industry: "Information Technology",
    location: "San Francisco, CA",
    openPositions: 12,
    totalApplications: 245,
    hired: 28,
    rejected: 185,
    inProgress: 32,
    avgTimeToHire: "18 days",
    joinDate: "2022-04-15",
    logo: "/placeholder.svg"
  },
  {
    id: 2,
    name: "Innovate Systems",
    industry: "Software Development",
    location: "New York, NY",
    openPositions: 8,
    totalApplications: 180,
    hired: 22,
    rejected: 140,
    inProgress: 18,
    avgTimeToHire: "21 days",
    joinDate: "2022-05-20",
    logo: "/placeholder.svg"
  },
  {
    id: 3,
    name: "Global Tech",
    industry: "Technology Consulting",
    location: "Austin, TX",
    openPositions: 15,
    totalApplications: 320,
    hired: 35,
    rejected: 255,
    inProgress: 30,
    avgTimeToHire: "15 days",
    joinDate: "2022-03-10",
    logo: "/placeholder.svg"
  },
  {
    id: 4,
    name: "Webflow Enterprises",
    industry: "Web Development",
    location: "Seattle, WA",
    openPositions: 6,
    totalApplications: 150,
    hired: 18,
    rejected: 110,
    inProgress: 22,
    avgTimeToHire: "24 days",
    joinDate: "2022-06-05",
    logo: "/placeholder.svg"
  },
  {
    id: 5,
    name: "Smart Solutions",
    industry: "AI & Machine Learning",
    location: "Boston, MA",
    openPositions: 10,
    totalApplications: 210,
    hired: 26,
    rejected: 155,
    inProgress: 29,
    avgTimeToHire: "19 days",
    joinDate: "2022-04-25",
    logo: "/placeholder.svg"
  }
];

// Sample positions data
const positions = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    applications: 48,
    hired: 5,
    rejected: 35,
    inProgress: 8,
    type: "Full-time",
    experience: "5+ years"
  },
  {
    id: 2,
    title: "Backend Engineer",
    applications: 42,
    hired: 4,
    rejected: 32,
    inProgress: 6,
    type: "Full-time",
    experience: "3+ years"
  },
  {
    id: 3,
    title: "DevOps Specialist",
    applications: 38,
    hired: 3,
    rejected: 28,
    inProgress: 7,
    type: "Full-time",
    experience: "4+ years"
  },
  {
    id: 4,
    title: "Product Manager",
    applications: 35,
    hired: 2,
    rejected: 29,
    inProgress: 4,
    type: "Full-time",
    experience: "6+ years"
  },
  {
    id: 5,
    title: "UX/UI Designer",
    applications: 40,
    hired: 4,
    rejected: 30,
    inProgress: 6,
    type: "Full-time",
    experience: "3+ years"
  }
];

interface AdminCompaniesListProps {
  searchQuery?: string;
}

export function AdminCompaniesList({ searchQuery = "" }: AdminCompaniesListProps) {
  const [selectedCompany, setSelectedCompany] = useState<any>(null);
  const [filteredCompanies, setFilteredCompanies] = useState(companies);

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredCompanies(companies);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = companies.filter(
        company => 
          company.name.toLowerCase().includes(query) || 
          company.industry.toLowerCase().includes(query) || 
          company.location.toLowerCase().includes(query)
      );
      setFilteredCompanies(filtered);
    }
  }, [searchQuery]);

  return (
    <>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Company</TableHead>
                <TableHead>Open Positions</TableHead>
                <TableHead>Applications</TableHead>
                <TableHead>Hiring Rate</TableHead>
                <TableHead>Avg Time to Hire</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCompanies.length > 0 ? (
                filteredCompanies.map((company) => (
                  <TableRow key={company.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <img 
                          src={company.logo} 
                          alt={company.name} 
                          className="h-9 w-9 mr-3 rounded-full"
                        />
                        <div>
                          <p className="font-medium">{company.name}</p>
                          <p className="text-sm text-gray-500">{company.location}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Badge className="bg-blue-500">{company.openPositions}</Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-1">
                        <span className="font-medium">{company.totalApplications}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">
                          {Math.round((company.hired / company.totalApplications) * 100)}%
                        </span>
                        <div className="flex space-x-1 text-sm">
                          <span className="text-green-500">{company.hired}</span>
                          <span className="text-gray-400">/</span>
                          <span className="text-red-500">{company.rejected}</span>
                          <span className="text-gray-400">/</span>
                          <span className="text-amber-500">{company.inProgress}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{company.avgTimeToHire}</TableCell>
                    <TableCell>{new Date(company.joinDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setSelectedCompany(company)}
                      >
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No companies found matching "{searchQuery}"
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Company Details Dialog */}
      <Dialog open={!!selectedCompany} onOpenChange={(open) => !open && setSelectedCompany(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Company Details</DialogTitle>
            <DialogDescription>
              Detailed information about the company's hiring process and statistics
            </DialogDescription>
          </DialogHeader>
          
          {selectedCompany && (
            <div>
              <div className="flex items-center mb-6">
                <img
                  src={selectedCompany.logo}
                  alt={selectedCompany.name}
                  className="h-16 w-16 mr-4 rounded-full"
                />
                <div>
                  <h3 className="text-xl font-semibold">{selectedCompany.name}</h3>
                  <p className="text-gray-500">{selectedCompany.location}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{selectedCompany.industry}</Badge>
                    <Badge variant="outline">Joined {new Date(selectedCompany.joinDate).toLocaleDateString()}</Badge>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex flex-col items-center">
                      <h4 className="font-medium text-gray-500 mb-1">Applications</h4>
                      <p className="text-3xl font-bold">{selectedCompany.totalApplications}</p>
                      <div className="flex items-center space-x-2 mt-2 text-sm">
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                          <span>{selectedCompany.hired}</span>
                        </div>
                        <div className="flex items-center">
                          <XCircle className="h-4 w-4 text-red-500 mr-1" />
                          <span>{selectedCompany.rejected}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-amber-500 mr-1" />
                          <span>{selectedCompany.inProgress}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex flex-col items-center">
                      <h4 className="font-medium text-gray-500 mb-1">Hiring Rate</h4>
                      <p className="text-3xl font-bold">
                        {Math.round((selectedCompany.hired / selectedCompany.totalApplications) * 100)}%
                      </p>
                      <p className="text-sm text-gray-500 mt-2">Industry avg: 15%</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex flex-col items-center">
                      <h4 className="font-medium text-gray-500 mb-1">Time to Hire</h4>
                      <p className="text-3xl font-bold">{selectedCompany.avgTimeToHire}</p>
                      <p className="text-sm text-gray-500 mt-2">Industry avg: 22 days</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Tabs defaultValue="positions">
                <TabsList className="mb-4">
                  <TabsTrigger value="positions">Open Positions</TabsTrigger>
                  <TabsTrigger value="analytics">Hiring Analytics</TabsTrigger>
                </TabsList>
                
                <TabsContent value="positions">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Position</TableHead>
                        <TableHead>Applications</TableHead>
                        <TableHead>Hiring Status</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Experience</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {positions.map((position) => (
                        <TableRow key={position.id}>
                          <TableCell>
                            <div className="font-medium">{position.title}</div>
                          </TableCell>
                          <TableCell>{position.applications}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-1">
                              <span className="font-medium">
                                {Math.round((position.hired / position.applications) * 100)}%
                              </span>
                              <div className="flex space-x-1 text-xs">
                                <span className="text-green-500">{position.hired}</span>
                                <span className="text-gray-400">/</span>
                                <span className="text-red-500">{position.rejected}</span>
                                <span className="text-gray-400">/</span>
                                <span className="text-amber-500">{position.inProgress}</span>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{position.type}</TableCell>
                          <TableCell>{position.experience}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TabsContent>
                
                <TabsContent value="analytics">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-3">Application Pipeline</h4>
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Initial Application</span>
                              <span className="text-sm font-medium">100%</span>
                            </div>
                            <Progress value={100} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Resume Screening</span>
                              <span className="text-sm font-medium">48%</span>
                            </div>
                            <Progress value={48} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Phone Interview</span>
                              <span className="text-sm font-medium">35%</span>
                            </div>
                            <Progress value={35} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Technical Assessment</span>
                              <span className="text-sm font-medium">22%</span>
                            </div>
                            <Progress value={22} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Final Interview</span>
                              <span className="text-sm font-medium">15%</span>
                            </div>
                            <Progress value={15} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Offer Extended</span>
                              <span className="text-sm font-medium">12%</span>
                            </div>
                            <Progress value={12} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Hired</span>
                              <span className="text-sm font-medium">11%</span>
                            </div>
                            <Progress value={11} className="h-2" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <h4 className="font-medium mb-3">Hiring Performance by Month</h4>
                        <div className="flex items-center justify-center h-48 bg-gray-50 rounded-md">
                          <BarChart className="h-10 w-10 text-gray-400" />
                          <span className="ml-2 text-gray-500">Analytics Chart Placeholder</span>
                        </div>
                        <div className="flex justify-center mt-3 space-x-4 text-sm">
                          <div className="flex items-center">
                            <div className="h-3 w-3 rounded-full bg-green-500 mr-1"></div>
                            <span>Hired</span>
                          </div>
                          <div className="flex items-center">
                            <div className="h-3 w-3 rounded-full bg-red-500 mr-1"></div>
                            <span>Rejected</span>
                          </div>
                          <div className="flex items-center">
                            <div className="h-3 w-3 rounded-full bg-blue-500 mr-1"></div>
                            <span>Applications</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
