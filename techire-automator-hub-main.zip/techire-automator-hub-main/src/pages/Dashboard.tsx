
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarChart, BriefcaseIcon, Calendar, CheckCircle, Edit, FileText, Upload, User, XCircle, Moon, Sun } from "lucide-react";
import { ApplicationsList } from "@/components/ApplicationsList";
import { CompanyList } from "@/components/CompanyList";
import { ProfileForm } from "@/components/ProfileForm";
import { ResumeUploader } from "@/components/ResumeUploader";
import { ResumeBuilder } from "@/components/ResumeBuilder";
import { useTheme } from "@/components/ThemeProvider";

export default function Dashboard() {
  const [userProfile, setUserProfile] = useState({
    name: "John Doe",
    title: "Software Developer",
    experience: "5",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    skills: "JavaScript, React, TypeScript, Node.js, HTML, CSS",
    about: "Experienced software developer with a passion for creating intuitive and performant web applications.",
    avatar: "/placeholder.svg"
  });
  
  const [profileProgress, setProfileProgress] = useState<number>(65);
  const [profileFormVisible, setProfileFormVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);

  const handleProfileUpdate = (data: any, progress: number) => {
    setUserProfile(data);
    setProfileProgress(progress);
    setProfileFormVisible(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="text-lg animate-pulse">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-primary">Techire</h1>
          <p className="text-gray-500">Your Job Application Dashboard</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="rounded-full hover:scale-105 transition-transform"
          >
            {theme === "dark" ? <Sun className="h-[1.2rem] w-[1.2rem]" /> : <Moon className="h-[1.2rem] w-[1.2rem]" />}
          </Button>
          <Button variant="outline" onClick={() => window.location.href = "/"}>
            Logout
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Profile Section */}
        <div className="md:col-span-3">
          <Card className="relative mb-6 hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Profile</CardTitle>
              <CardDescription>Your profile completeness</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center p-2">
                <Avatar className="h-24 w-24 mb-4 border-2 border-primary hover:scale-105 transition-transform duration-300">
                  <AvatarImage src={userProfile.avatar} alt="User" />
                  <AvatarFallback>{userProfile.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <h3 className="text-lg font-semibold">{userProfile.name}</h3>
                <p className="text-sm text-gray-500">{userProfile.title}</p>
                <p className="text-sm text-gray-500">{userProfile.experience} years experience</p>
                
                <div className="w-full mt-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Profile Completeness</span>
                    <span className="text-sm font-semibold">{profileProgress}%</span>
                  </div>
                  <Progress value={profileProgress} className="h-2" />
                </div>
                
                <div className="mt-4 space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => setProfileFormVisible(true)}
                    className="flex items-center gap-1 hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    <Edit className="h-4 w-4" /> Edit Profile
                  </Button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex items-center gap-1 hover:bg-primary hover:text-primary-foreground transition-colors"
                      >
                        <FileText className="h-4 w-4" /> Resume
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[525px]">
                      <DialogHeader>
                        <DialogTitle>Resume Management</DialogTitle>
                        <DialogDescription>
                          Upload your existing resume or build a new one
                        </DialogDescription>
                      </DialogHeader>
                      <Tabs defaultValue="upload">
                        <TabsList className="w-full mb-4">
                          <TabsTrigger value="upload" className="flex-1">
                            <Upload className="h-4 w-4 mr-2" /> Upload Resume
                          </TabsTrigger>
                          <TabsTrigger value="build" className="flex-1">
                            <FileText className="h-4 w-4 mr-2" /> Build Resume
                          </TabsTrigger>
                        </TabsList>
                        <TabsContent value="upload">
                          <ResumeUploader />
                        </TabsContent>
                        <TabsContent value="build">
                          <ResumeBuilder />
                        </TabsContent>
                      </Tabs>
                      <div className="mt-4">
                        <Button 
                          variant="outline" 
                          className="w-full hover:bg-primary hover:text-primary-foreground transition-colors"
                          onClick={() => window.open("https://resumeworded.com/resume-scanner", "_blank")}
                        >
                          <BarChart className="h-4 w-4 mr-2" /> 
                          Check ATS Score
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow duration-300">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Application Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <BriefcaseIcon className="h-5 w-5 mr-2 text-gray-500" />
                    <span>Total Applied</span>
                  </div>
                  <span className="font-semibold">24</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                    <span>Selected</span>
                  </div>
                  <span className="font-semibold">8</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <XCircle className="h-5 w-5 mr-2 text-red-500" />
                    <span>Rejected</span>
                  </div>
                  <span className="font-semibold">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-blue-500" />
                    <span>In Progress</span>
                  </div>
                  <span className="font-semibold">4</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="md:col-span-9">
          <Tabs defaultValue="applications">
            <TabsList className="mb-6">
              <TabsTrigger value="applications">My Applications</TabsTrigger>
              <TabsTrigger value="companies">Browse Companies</TabsTrigger>
            </TabsList>
            
            <TabsContent value="applications">
              <ApplicationsList />
            </TabsContent>
            
            <TabsContent value="companies">
              <CompanyList />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Profile Edit Form Dialog */}
      <Dialog open={profileFormVisible} onOpenChange={setProfileFormVisible}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
            <DialogDescription>
              Update your profile information
            </DialogDescription>
          </DialogHeader>
          <ProfileForm 
            onSave={handleProfileUpdate} 
            initialData={userProfile}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
