
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart4, BriefcaseIcon, Building, CheckCircle, Clock, Search, User, Users, XCircle, Moon, Sun } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AdminUsersList } from "@/components/AdminUsersList";
import { AdminCompaniesList } from "@/components/AdminCompaniesList";
import { useTheme } from "@/components/ThemeProvider";

export default function Admin() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("users");
  const [isLoading, setIsLoading] = useState(true);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="text-lg animate-pulse">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-primary">Techire</h1>
          <p className="text-gray-500">Admin Dashboard</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="rounded-full hover:scale-105 transition-transform"
          >
            {theme === "dark" ? <Sun className="h-[1.2rem] w-[1.2rem]" /> : <Moon className="h-[1.2rem] w-[1.2rem]" />}
          </Button>
          <Button variant="outline" onClick={() => window.location.href = "/"}>
            Logout
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Users</CardTitle>
            <CardDescription>Total registered users</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="h-8 w-8 mr-3 text-primary" />
              <span className="text-3xl font-bold">1,245</span>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Companies</CardTitle>
            <CardDescription>Registered companies</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Building className="h-8 w-8 mr-3 text-primary" />
              <span className="text-3xl font-bold">87</span>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Applications</CardTitle>
            <CardDescription>Total job applications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <BriefcaseIcon className="h-8 w-8 mr-3 text-primary" />
              <span className="text-3xl font-bold">4,312</span>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Hiring Rate</CardTitle>
            <CardDescription>Average success rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 mr-3 text-green-500" />
              <span className="text-3xl font-bold">32%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mb-8">
        <Card className="hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-2">
            <CardTitle>Application Statistics</CardTitle>
            <CardDescription>Overall platform performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Selected</span>
                  <span className="font-medium">1,380 (32%)</span>
                </div>
                <Progress value={32} className="h-2 bg-gray-200" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Rejected</span>
                  <span className="font-medium">1,819 (42%)</span>
                </div>
                <Progress value={42} className="h-2 bg-gray-200" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>In Progress</span>
                  <span className="font-medium">1,113 (26%)</span>
                </div>
                <Progress value={26} className="h-2 bg-gray-200" />
              </div>
            </div>

            <div className="mt-8 space-y-2">
              <div className="flex justify-between">
                <span>Interview Stage</span>
                <span className="font-medium">684 (62%)</span>
              </div>
              <Progress value={62} className="h-2 bg-gray-200" />
              
              <div className="flex justify-between">
                <span>Technical Test</span>
                <span className="font-medium">265 (24%)</span>
              </div>
              <Progress value={24} className="h-2 bg-gray-200" />
              
              <div className="flex justify-between">
                <span>HR Round</span>
                <span className="font-medium">164 (14%)</span>
              </div>
              <Progress value={14} className="h-2 bg-gray-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6 flex justify-between items-center">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input 
            placeholder={`Search ${activeTab === 'users' ? 'users' : 'companies'}...`} 
            className="pl-8" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="users" onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="companies">Companies</TabsTrigger>
        </TabsList>
        
        <TabsContent value="users">
          <AdminUsersList searchQuery={searchQuery} />
        </TabsContent>
        
        <TabsContent value="companies">
          <AdminCompaniesList searchQuery={searchQuery} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
